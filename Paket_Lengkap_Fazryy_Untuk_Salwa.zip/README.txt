PAKET WEBSITE PERMINTAAN MAAF FAZRYy UNTUK SALWA

Isi:
1. index.html = website permintaan maaf.
2. QR_Code_Website_Fazryy_Salwa.png = QR Code.

PENTING:
QR saat ini menggunakan URL contoh:
https://example.com/fazryy-untuk-salwa

Agar QR benar-benar membuka website, upload index.html ke hosting
(GitHub Pages, Netlify, Vercel, atau hosting lainnya), lalu buat QR baru
dengan URL website yang sebenarnya.
